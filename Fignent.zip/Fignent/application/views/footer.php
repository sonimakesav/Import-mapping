<!-- main content part end -->

<!-- footer  -->
<!-- jquery slim -->
<script src="<?php echo base_url(); ?>assets/js/jquery-3.4.1.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<!-- popper js -->
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
<!-- bootstarp js -->
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<!-- sidebar menu  -->
<script src="<?php echo base_url(); ?>assets/js/metisMenu.js"></script>
<!-- waypoints js -->
<script src="<?php echo base_url(); ?>assets/vendors/count_up/jquery.waypoints.min.js"></script>
<!-- waypoints js -->
<script src="<?php echo base_url(); ?>assets/vendors/chartlist/Chart.min.js"></script>
<!-- counterup js -->
<script src="<?php echo base_url(); ?>assets/vendors/count_up/jquery.counterup.min.js"></script>
<!-- swiper slider js -->
<script src="<?php echo base_url(); ?>assets/vendors/swiper_slider/js/swiper.min.js"></script>
<!-- nice select -->
<script src="<?php echo base_url(); ?>assets/vendors/niceselect/js/jquery.nice-select.min.js"></script>
<!-- owl carousel -->
<script src="<?php echo base_url(); ?>assets/vendors/owl_carousel/js/owl.carousel.min.js"></script>
<!-- gijgo css -->
<script src="<?php echo base_url(); ?>assets/vendors/gijgo/gijgo.min.js"></script>
<!-- responsive table -->
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/buttons.flash.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/vendors/datatable/js/buttons.print.min.js"></script>


<!-- progressbar js -->
<script src="<?php echo base_url(); ?>assets/vendors/progressbar/jquery.barfiller.js"></script>
<!-- tag input -->
<script src="<?php echo base_url(); ?>assets/vendors/tagsinput/tagsinput.js"></script>
<!-- text editor js -->
<script src="<?php echo base_url(); ?>assets/vendors/text_editor/summernote-bs4.js"></script>


<!-- custom js -->
<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>



</body>

<!-- Mirrored from demo.dashboardpack.com/finance-html/data_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 29 Aug 2021 09:47:02 GMT -->
</html>