

The CodeIgniter team would like to thank EllisLab, all the
contributors to the CodeIgniter project and you, the CodeIgniter user.


***************
How to setup the project?
***************
Copy past the folder in the xamp 
employee_details table exported file is in the directory it self
import that file in you database
Configure the db details in Mainfolder/applivation/config/database
Click on http://localhost/Fignent/
Sample csv is attached in this folder itself.
